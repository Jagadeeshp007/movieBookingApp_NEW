package com.rbp.moviebookingapp.models;

public enum ERole {
	ROLE_USER,
	ROLE_GUEST,
	ROLE_ADMIN
}